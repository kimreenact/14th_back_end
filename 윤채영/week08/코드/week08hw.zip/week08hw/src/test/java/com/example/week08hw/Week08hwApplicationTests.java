package com.example.week08hw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week08hwApplicationTests {

    @Test
    void contextLoads() {
    }

}
