package com.example.week08hw.service;

import com.example.week08hw.domain.Post;
import com.example.week08hw.dto.request.PostCreateRequest;
import com.example.week08hw.dto.request.PostUpdateRequest;
import com.example.week08hw.dto.response.PostResponse;
import com.example.week08hw.repository.PostRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PostService {

    private final PostRepository postRepository;

    public PostService(PostRepository postRepository) {
        this.postRepository = postRepository;
    }

    // 생성
    public PostResponse create(PostCreateRequest request) {
        Post post = postRepository.save(
                request.title(),
                request.content(),
                request.author()
        );

        return PostResponse.from(post);
    }

    // 전체 조회
    public List<PostResponse> findAll() {
        return postRepository.findAll()
                .stream()
                .map(PostResponse::from)
                .toList();
    }

    // 상세 조회
    public PostResponse findById(Long id) {
        Post post = postRepository.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException("존재하지 않는 게시글입니다."));

        return PostResponse.from(post);
    }

    // 수정
    public PostResponse update(Long id, PostUpdateRequest request) {
        Post post = postRepository.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException("존재하지 않는 게시글입니다."));

        post.update(
                request.title(),
                request.content(),
                request.author()
        );

        return PostResponse.from(post);
    }

    // 삭제
    public void delete(Long id) {
        Post post = postRepository.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException("존재하지 않는 게시글입니다."));

        postRepository.delete(post);
    }
}