package com.example.week08hw.dto.response;

import com.example.week08hw.domain.Post;

public record PostResponse(
        Long id,
        String title,
        String content,
        String author
) {

    public static PostResponse from(Post post) {
        return new PostResponse(
                post.getId(),
                post.getTitle(),
                post.getContent(),
                post.getAuthor()
        );
    }
}