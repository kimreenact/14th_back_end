package com.example.week08hw.dto.request;

public record PostUpdateRequest (
        String title,
        String content,
        String author
) {
}
