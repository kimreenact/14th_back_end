package com.example.week08hw.controller;

import com.example.week08hw.dto.request.PostCreateRequest;
import com.example.week08hw.dto.request.PostUpdateRequest;
import com.example.week08hw.dto.response.PostResponse;
import com.example.week08hw.service.PostService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Tag(
        name = "Post api",
        description = "게시글 관리 API"
)

@RestController
@RequestMapping("/api/posts")
public class PostController {
    private final PostService postService;

    public PostController(PostService postService){
        this.postService = postService;
    }

    @Operation(summary = "게시글 생성")
    @PostMapping
    public PostResponse create(@RequestBody PostCreateRequest request){
        return postService.create(request);
    }
    @Operation(summary = "게시글 전체 조회")
    @GetMapping
    public List<PostResponse> findAll(){
        return postService.findAll();
    }

    @Operation(summary = "게시글 상세 조회")
    @GetMapping("/{id}")
    public PostResponse findById(@PathVariable Long id){
        return postService.findById(id);
    }

    @Operation(summary = "게시글 수정")
    @PatchMapping("/{id}")
    public PostResponse update(
            @PathVariable Long id,
            @RequestBody PostUpdateRequest request
    ){
        return postService.update(id,request);
    }

    @Operation(summary = "게시글 삭제")
    @DeleteMapping("/{id}")
    public Map<String, String > delete(@PathVariable Long id){
        postService.delete(id);

        return Map.of(
                "message",
                "게시물이 삭제되었습니다."
        );
    }

}
