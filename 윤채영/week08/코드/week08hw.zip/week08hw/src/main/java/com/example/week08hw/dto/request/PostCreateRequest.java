package com.example.week08hw.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;

public record PostCreateRequest (
        @Schema(description = "게시글 제목")
        String title,

        @Schema(description = "게시글 내용")
        String content,

        @Schema(description = "작성자")
        String author
) {
}
