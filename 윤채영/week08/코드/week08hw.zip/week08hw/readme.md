# 8주차 과제 - 게시글 관리 API

## 프로젝트 소개

Spring Boot를 활용하여 게시글 CRUD(Create, Read, Update, Delete) 기능을 구현한 REST API 프로젝트입니다.

Swagger(OpenAPI)를 이용하여 API 문서화를 진행하였으며, Postman을 통해 API 테스트를 수행하였습니다.

---

## 기술 스택

- Java 17
- Spring Boot
- Lombok
- Swagger (SpringDoc OpenAPI)
- Postman

---

# API 명세

## 1. 게시글 생성

### Request

- Method: POST
- URL: `/api/posts`

### Request Body

```json
{
  "title": "첫 번째 게시글",
  "content": "안녕하세요",
  "author": "YCY"
}
```

### Response

```json
{
  "id": 1,
  "title": "첫 번째 게시글",
  "content": "안녕하세요",
  "author": "YCY"
}
```

---

## 2. 게시글 전체 조회

### Request

- Method: GET
- URL: `/api/posts`

### Response

```json
[
  {
    "id": 1,
    "title": "첫 번째 게시글",
    "content": "안녕하세요",
    "author": "YCY"
  }
]
```

---

## 3. 게시글 상세 조회

### Request

- Method: GET
- URL: `/api/posts/{id}`

### Example

```
GET /api/posts/1
```

### Response

```json
{
  "id": 1,
  "title": "첫 번째 게시글",
  "content": "안녕하세요",
  "author": "YCY"
}
```

---

## 4. 게시글 수정

### Request

- Method: PATCH
- URL: `/api/posts/{id}`

### Request Body

```json
{
  "title": "수정된 제목",
  "content": "수정된 내용",
  "author": "YCY"
}
```

### Response

```json
{
  "id": 1,
  "title": "수정된 제목",
  "content": "수정된 내용",
  "author": "YCY"
}
```

---

## 5. 게시글 삭제

### Request

- Method: DELETE
- URL: `/api/posts/{id}`

### Example

```
DELETE /api/posts/1
```

### Response

```json
{
  "message": "게시물이 삭제되었습니다."
}
```

---

# 예외 처리

존재하지 않는 게시글 ID로 조회, 수정, 삭제 요청 시 예외가 발생하도록 구현하였습니다.

### 예시

```
GET /api/posts/999
PATCH /api/posts/999
DELETE /api/posts/999
```

### Response

```json
{
  "message": "존재하지 않는 게시글입니다."
}
```

---

# Swagger UI

Swagger를 통해 API 문서를 확인할 수 있습니다.

```
http://localhost:8081/swagger-ui/index.html
```

### Swagger 실행 화면

> Swagger UI 캡처 이미지 첨부

---

# Postman 테스트

### 게시글 생성

> Postman POST 테스트 캡처 첨부

### 게시글 전체 조회

> Postman GET 테스트 캡처 첨부

### 게시글 상세 조회

> Postman GET(id) 테스트 캡처 첨부

### 게시글 수정

> Postman PATCH 테스트 캡처 첨부

### 게시글 삭제

> Postman DELETE 테스트 캡처 첨부

---

# 프로젝트 구조

```text
src/main/java/com/example/week08hw

├── controller
│   └── PostController
├── service
│   └── PostService
├── repository
│   └── PostRepository
├── domain
│   └── Post
├── dto
│   ├── request
│   │   ├── PostCreateRequest
│   │   └── PostUpdateRequest
│   └── response
│       └── PostResponse
└── Week08hwApplication
```

---

# 키워드 과제

## DTO(Data Transfer Object)의 중요성

DTO는 계층 간 데이터를 전달하기 위한 객체입니다.

DTO를 사용하면 Entity를 직접 노출하지 않고 필요한 데이터만 전달할 수 있어 보안성과 유지보수성이 향상됩니다.

또한 Request DTO와 Response DTO를 분리하여 클라이언트와 서버 간 데이터 교환을 명확하게 관리할 수 있습니다.

본 프로젝트에서는 다음 DTO를 사용하였습니다.

- PostCreateRequest
- PostUpdateRequest
- PostResponse

---

## Java Record

Record는 데이터를 저장하기 위한 불변(Immutable) 객체를 간편하게 생성할 수 있는 Java 문법입니다.

기존 클래스와 달리 생성자, getter, equals(), hashCode(), toString() 등을 자동으로 생성해주므로 코드가 간결해집니다.

예시

```java
public record PostCreateRequest(
        String title,
        String content,
        String author
) {
}
```

본 프로젝트에서는 Request DTO와 Response DTO를 Record로 구현하여 불필요한 코드를 줄이고 가독성을 높였습니다.

---

## Path Variable

Path Variable은 URL 경로에 포함된 값을 받아오는 방식입니다.

예시

```java
@GetMapping("/{id}")
public PostResponse findById(@PathVariable Long id) {
    return postService.findById(id);
}
```

요청 URL

```
GET /api/posts/1
```

위 요청에서 `1`이 Path Variable로 전달되어 id 값으로 사용됩니다.

본 프로젝트에서는 게시글 상세 조회, 수정, 삭제 기능에서 Path Variable을 사용하였습니다.

---

## Query Parameter

Query Parameter는 URL 뒤에 `?`를 사용하여 데이터를 전달하는 방식입니다.

예시

```java
@GetMapping("/search")
public String search(@RequestParam String keyword) {
    return keyword;
}
```

요청 URL

```
GET /search?keyword=spring
```

위 요청에서 `spring`이 keyword 값으로 전달됩니다.

본 프로젝트에서는 Query Parameter를 직접 사용하지는 않았지만, 검색 기능이나 필터링 기능을 구현할 때 주로 사용됩니다.

예시

```
GET /api/posts?author=YCY
GET /api/posts?page=1
GET /api/posts?keyword=Spring
```